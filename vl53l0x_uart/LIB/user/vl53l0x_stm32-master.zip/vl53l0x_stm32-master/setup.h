#ifndef SETUP_H
#define SETUP_H

void setup(void);

#endif /* SETUP_H */
